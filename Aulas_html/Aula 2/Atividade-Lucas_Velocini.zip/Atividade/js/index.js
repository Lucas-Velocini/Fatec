function enviar_email(){
const nome = prompt('Informe o seu nome: ');
const email = prompt('Informe o seu e-mail: ');
const msg = prompt('Digite a mensagem ue deseja enviar: ');

alert('Confira os Dados');
alert('Nome: ' + nome);
alert('E-mail: ' + email);
alert('Mensagem: ' + msg);
alert('Obrigado por entrar em contato!');
}
